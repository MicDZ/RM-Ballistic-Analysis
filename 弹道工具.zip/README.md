## 简介
一个用于分析弹道的程序。

![效果图](20240424_9m_1.png)

## 依赖
```
python
numpy
opencv
tkinter
PIL
```

## 使用
```
python ui.py
```

